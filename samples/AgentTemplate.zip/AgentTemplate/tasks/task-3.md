# Task 2 - Create Flow Activities

## Task Description

[NA]

## Variables

- $ActivityName: `SampleActivity`

## Steps

- Follow [Creating an Activity](docs/1-getting-started/3-activity-flow.md) to create a new activity with the name `{$ActivityName}.cs` in the `{$PROJECT_NAME}.Src` folder.
