# Task 1 - Create a New Project

## Task Description

[NA]

## Variables

[NA]

## Steps

- Add .gitignore file to the project for a typical .net console project. Add .env to the .gitignore file.
- Follow  [Setting up Guide](docs/1-getting-started/1-setting-up.md) to create a new project with the name `{$PROJECT_NAME}`.
  - Install necessary libraries as the guide says.
  - Once everything is in place, build the project and validate the setup as per the documentation.
- Copy [.env](.env) file to `{$PROJECT_NAME}` folder.
