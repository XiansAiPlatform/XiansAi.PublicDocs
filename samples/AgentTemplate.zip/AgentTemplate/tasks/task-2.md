# Task 2 - Create a Flow

## Task Description

[NA]

## Variables

- $FlowName = ConversingFlow

## Steps

- Follow [Creating a Flow](docs/1-getting-started/2-first-flow.md) to create a new flow with the name `{$PROJECT_NAME}Flow.cs` in the `{$PROJECT_NAME}.Src` folder.
